﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightLib
{
    public class FlightPlanList
    {
        FlightPlan[] vector = new FlightPlan[10];
        int number = 0;

        public int GetNumber()
        { return number; }

        public void SetNumber(int number)
        { this.number = number; }


        public int AddFlightPlan(FlightPlan p)
        {
            if (number == 10)
            {
                return -1; // Lista llena
            }
            else
            {
                vector[number] = p;
                number++;
                return 0;
            }
        }
        public FlightPlan GetFlightPlan(int i)
        {
            if (i<0 || i >= number)
            {
                return null; // Índice fuera de rango
            }
            else
            {
                return vector[i];
            }
        }
        public void Mover (double tiempo)
        {
            int i = 0;
            while (i < number)
            {
                vector[i].Mover(tiempo);
                i++;
            }
        }
        public void EscribeConsola()
        {
            int i = 0;
            while (i < number)
            {
                vector[i].EscribeConsola();
                i++;
            }
        }
    }
}
